from langdetect import detect, LangDetectException
import pandas as pd
import logging
from dataclasses import dataclass
from typing import Union


@dataclass
class KeywordDataFrameFields:
    id_field: str
    eng_name_field: str
    fr_name_field: str
    idf_field: Union[float, None] = None


@dataclass
class ResumeDataFrameFields:
    resume_field: str
    language_field: str
    id_field: Union[str, None] = None


FRENCH = "fr"
ENGLISH = "en"


ENGLISH_SOFTSKILLS = ['autonomy', 'communication', 'creativity', 'leadership', 'motivation', 
                      'other', 'problem solving', 'teamwork', 'technical', 'time management', 'work ethics']
FRENCH_SOFTSKILLS = ['autonomie', 'autre', 'communication', 'créativité', 'gestion du temps', 
                     'leadership', 'motivation', 'résolution de problèmes', 'technique', 
                     "travail d'équipe", 'éthique du travail']
LABELS_TO_EXCLUDE = ['other', 'autre', 'technical', 'technique']
EN_TO_FR = {'autonomy': 'autonomie', 
                'communication': 'communication', 
                'creativity': 'créativité',
                'leadership': 'leadership', 
                'motivation': 'motivation', 
                'other': 'autre', 
                'problem solving': 'résolution de problèmes',
                'teamwork': "travail d'équipe", 
                'technical': 'technique', 
                'time management': 'gestion du temps', 
                'work ethics': 'éthique du travail'}

SKILLS_DF_FIELDS = KeywordDataFrameFields('SkillID', 'SkillName', 'SkillName_FR', 'IDF')
JOB_TITLE_FIELDS = KeywordDataFrameFields('Job_id', 'Name', 'Name_fr', 'IDF')
JOB_SKILL_FIELDS = KeywordDataFrameFields('ID', 'Name', 'NameFR', 'IDF')
COMBINED_FIELDS = KeywordDataFrameFields('CombinedID', 'Name', 'Name_fr', 'IDF')
RESUME_FIELDS = ResumeDataFrameFields('Resume', 'Language', 'ResumeID')


def detect_language(text: str):
    """
    Detects language from a text.

    Parameters
    ----------
    text: string

    Returns
    -------
    'en' or 'fr'
    """
    try:
        language = detect(text)
        if language in [ENGLISH, FRENCH]:
            return language
        else:
            return ENGLISH
    except LangDetectException:
        logging.info('Could not detect language. Defaulting to english.')
        return ENGLISH


def get_top_candidates(ranking: dict, top: int = 10):
    """
    Sorts the ranking of the first 'top' candidates.

    Parameters
    ----------
    ranking: a dictionary of ranking scores for each candidate.
    top: integer values, 10 by default.

    Returns
    -------
    A list of integers for the first top candidates
    """
    return [int(k) if type(k) != int else k for k, _ in
            sorted(ranking.items(), key=lambda item: item[1], reverse=True)][:top]


def create_combined_df(skills_df: pd.DataFrame, jobs_df: pd.DataFrame,
                       CombinedFields: KeywordDataFrameFields = COMBINED_FIELDS):
    """
    Concatenates skill and job position databases.

    Input
    ----------
    skills_df: pandas dataframe of skills.
    jobs_df: pandas dataframe of job positions.
    CombinedFields: KeywordDataFrameFields class.

    Output
    -------
    A pandas dataframe containing skills and job positions.
    """
    modified_jobs_df = jobs_df.copy()
    modified_skills_df = skills_df.copy()
    id_column_name = CombinedFields.id_field
    eng_column_name = CombinedFields.eng_name_field
    fr_column_name = CombinedFields.fr_name_field
    modified_jobs_df.columns = ['ID', eng_column_name, fr_column_name]
    modified_skills_df.columns = ['ID', eng_column_name, fr_column_name]
    modified_jobs_df[id_column_name] = modified_jobs_df['ID'].astype(int) + \
        modified_skills_df['ID'].astype(int).max() + 1
    modified_skills_df[id_column_name] = modified_skills_df['ID']
    return pd.concat([modified_skills_df, modified_jobs_df])


def df_has_correct_types(df: pd.DataFrame, df_fields: classmethod):
    """
    It enforces the correct types for all dataframes used in the ranking features library.

    Input
    ----------
    df: pandas dataframe.
    df_fields: class with column fields from df.

    Output
    -------
    True or False depending on whether the df have the right types for each column.
    """
    df_columns = df.columns
    if type(df_fields).__name__ == 'ResumeDataFrameFields':
        expected_dtypes = {col: 'object' for col in df_columns}
    elif type(df_fields).__name__ == 'KeywordDataFrameFields':
        object_column_fields = [df_fields.id_field, df_fields.eng_name_field, df_fields.fr_name_field]
        float_column_field = df_fields.idf_field
        expected_dtypes = {col: 'object' for col in df_columns if col in object_column_fields}
        if float_column_field:
            expected_dtypes[float_column_field] = 'float64'
    else:
        assert False, f"Unsupported df fields: {type(df_fields)}"
    for column in df_columns:
        if str(df[column].dtype) == expected_dtypes[column]:
            continue
        return False
    return True
