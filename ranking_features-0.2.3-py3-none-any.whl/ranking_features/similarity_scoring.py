import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from scipy.sparse import csr_matrix, SparseEfficiencyWarning
import warnings
from sentence_transformers import SentenceTransformer
from sentence_transformers.util import cos_sim


def get_similarity(job_desc_tfidf: csr_matrix, resumes_tfidf: csr_matrix, subset_row2id: dict, return_dict=False):
    """
    Computes cosine_similarity between a job description and a bunch of resumes

    Parameters
    ----------
    job_desc_tfidf: scipy.sparse
        A TF-IDF sparse matrix where the single document row represents the job description and the columns features 
        represent the keywords
    resumes_tfidf: scipy.sparse
        A TF-IDF sparse matrix where the document rows represent the resumes and the columns features 
        represent the keywords
    subset_row2id: dict
        Should be of format {sparse_matrix_row_index: ResumeID, sparse_matrix_row_index: ResumeID, ..}
        Dictionary linking the sparse matrix's rows to the ResumeIDs.

    Returns
    -------
    pd.Series
        Series of similarity scores between the job_text and the resumes
        The indices of the series are the same as the matching ResumeIDs
    """

    cosine_similarity_scores = cosine_similarity(job_desc_tfidf, resumes_tfidf).flatten()
    index = [subset_row2id[i] for i in range(cosine_similarity_scores.shape[0])]
    score_series = pd.Series(data=cosine_similarity_scores, index=index)
    return score_series if not return_dict else score_series.to_dict()


def get_top_words(matched_keyword_ids: list, resumes_tfidf_matrix: csr_matrix, col2id, row2id=None,
                  top_n: int = 3,  resumes_occurence_matrix: csr_matrix = None, threshold: int = 0):
    """
    Returns the keywords with the highest TF-IDF encoding values in the matched_keyword_ids list

    Parameters
    ----------
    matched_keyword_ids: list(int)
        A list of all the IDs for the keywords that were selected by the user. The IDs should match the rows of the
        resumes_tfidf_matrix
    resumes_tfidf_matrix: scipy.sparse
        A TF-IDF sparse matrix where the document rows represent the resumes and the columns features 
        represent the keywords. The values are the TF-IDF encoding of a given keyword in a given document.
    top_n: int
        The number of top keywords to return. Less will be returned if there are not enough matches.
    cold2id: dict
        A mapping from column index to keyword id
    row2id: dict | None
        A mapping from row index to resume ID. If not specified the resulting dict has row index as keys.
    resumes_occurence_matrix: scipy.sparse | None
        A sparse matrix where the document rows represent the resumes and the columns features 
        represent the keywords. The values are the number of occurence of a given keyword in a given document.
        Can be ignored if threshold is set to 0 (default value)
    threshold: int
        Number of times the keyword must appear in a resume. If the number of times is less than the threshold,
        the keyword will not be considered.
        If set to zero (default value), this condition is ignored.

    Returns
    -------
    dict
        Dictionary in the format of {rowID: [list of keywordIDs (int)], ...}, with the rowIDs corresponding to the
        resumes_tfidf_matrix and the keywordIDs corresponding to the top_n keyword column numbers in the tfidf_matrix.
    """
    id2col = {idx: col for col, idx in col2id.items()}  # id -> number
    sorted_keys = sorted(id2col, key=id2col.get)  # sorted ids by number
    id2idx = {key: index for index, key in enumerate(sorted_keys)}  # id -> compact index
    index_mapping = {i: id2col[k] for i, k in enumerate(sorted_keys)}  # compact index -> number
    matched_keyword_col = [id2idx[k_idx] for k_idx in matched_keyword_ids]
    # Matrix which will be a copy of resumes_tfidf_matrix, but with the values removed (zero) for columns that aren't
    # in the matched_keyword_ids list. Effectively, if a resume has keywords that aren't selected by the user,
    # we don't want to return those, as they do not positively impact the cosine similarity.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", SparseEfficiencyWarning)
        new_matrix = csr_matrix(resumes_tfidf_matrix.shape)
        new_matrix[:, matched_keyword_col] = resumes_tfidf_matrix[:, matched_keyword_col] 

    # If there is a threshold, we make a boolean matrix mask and do a cell-wise product between the mask and the matrix 
    # of matched TF-IDF scores
    if threshold > 0:
        if resumes_occurence_matrix is None:
            raise ValueError('When setting a threshold above 0, must provide an occurence count matrix')
        new_matrix = (resumes_occurence_matrix >= threshold).multiply(new_matrix)

    # For each row, we get the argsort of the raw data list, and we use row.indices to get the real columns.
    # Then we get the top_n.
    # Example :

    # top_n = 3
    # row = csr_matrix([0,0,0,7,0,0,5,0,6,0,8,0])

    # assert (row.indices == [3,6,8,10]).all() #the position of the non-zero values
    # assert (row.data == [7,5,6,8]).all() #the non-zero values
    # assert ((-row.data).argsort() == [3,0,2,1]).all() #the sorted indices of the row.data, from highest value to lower
    # assert (row.indices[[3,0,2,1]]  == [10,3,8,6]).all() #a rearrangement of the positions of the non-zero values
    top_n_idx = {}
    for i, row in enumerate(new_matrix):
        r_idx = row2id[i] if row2id is not None else i
        top_n_idx[r_idx] = [col2id[index_mapping[idx]] for idx in (row.indices[(-row.data).argsort()][:top_n]) if row[0,idx] != 0]
    return top_n_idx


def get_semantic_similarity_score(resumes_dict: dict, job_description_text: str,
                                  model=SentenceTransformer("all-MiniLM-L6-v2"), return_dict=False):
    """
    It returns all semantic similarities between the job descriptions and a pool of resumes.
    Input:
    ----------
    resumes_dict: a dictionary with keys as resumes ids and values as resume text
    job_description_text: string with job description text.
    model: SentenceTransformer("all-MiniLM-L6-v2").
    return_dict: if True, return result in dict format {id: score}, if not return in Series format

    Output:
    -------
    semantic_score_df: a pandas series with semantic cosine similarity between resume texts and a job
    description.
    """
    resume_texts = [resumes_dict[i] for i in resumes_dict.keys()]
    embeddings_job_description = model.encode(job_description_text, convert_to_tensor=True)
    embeddings_resume = model.encode(resume_texts, convert_to_tensor=True)
    similarity = cos_sim(embeddings_job_description, embeddings_resume)
    semantic_score_df = pd.Series(data=np.round(similarity.numpy()[0], 2), index=resumes_dict.keys())
    return semantic_score_df if not return_dict else semantic_score_df.to_dict()
