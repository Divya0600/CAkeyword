import re
import nltk
import pickle
import joblib
import numpy as np
from statistics import mean
from ranking_features.utils import ENGLISH, FRENCH, LABELS_TO_EXCLUDE, ENGLISH_SOFTSKILLS, \
    FRENCH_SOFTSKILLS, EN_TO_FR

import pandas as pd
from ranking_features.utils import RESUME_FIELDS, df_has_correct_types
from sklearn.feature_extraction.text import CountVectorizer

def clean_text_en(text: str):
    """
    This function is used to create a clean text before creating TF-IDF table.

    Input:
        text: This represents the soft skills related sentence that we want to clean.
    """
    replacements = {
        "what's": "what is",
        "'ve": " have",
        "can't": "can not",
        "n't": " not",
        "i'm": "i am",
        "'re": " are",
        "'d": " would",
        "'ll": " will",
        "'scuse": " excuse",
        "'s": ""
    }

    text = text.lower()

    for pattern, replacement in replacements.items():
        text = re.sub(re.escape(pattern), replacement, text)

    text = re.sub(r'\W', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def clean_text_fr(text: str):
    """
    This function is used to create a clean text before creating TF-IDF table.

    Input:
        text: This represents the soft skills related sentence that we want to clean.
    """
    replacements = {
        "c'est": "ce est",
        "qu'est-ce que": "que est ce que",
        "n'est": "ne est",
        "j'suis": "je suis",
        "j'ai": "je ai",
        "t'es": "tu es",
        "t'as": "tu as",
        "l'": "le ",
        "d'": "de ",
        "s'": "se ",
        "m'": "me ",
        "j'": "je ",
        "t'": "te ",
        "c'": "ce ",
        "qu'": "que ",
        "n'": "ne "
    }

    text = text.lower()

    for pattern, replacement in replacements.items():
        text = re.sub(re.escape(pattern), replacement, text)

    text = re.sub(r'\W', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def preprocess_resume(resume_text: str, language: str):
    """
    Input
    ----------
    resume_text: string of resume text.

    Output
    -------
    resume_lines: list of sentences from the resume.
    """
    resume_sentences = nltk.sent_tokenize(resume_text)
    clean_text = clean_text_en if language == ENGLISH else clean_text_fr
    resume_lines = [clean_text(line) for line in resume_sentences]
    return resume_lines


def load_model(model_path: str):
    """

    Input
    ----------
    model_path: string

    Output
    -------
    loaded_model: pickle model file
    """
    loaded_model = joblib.load(model_path)
    return loaded_model


def load_vectorizer(vectorizer_path: str):
    """
    Input
    ----------
    vectorizer_name: string

    Output
    -------
    vectorizer: loaded pickle file
    """
    with open(vectorizer_path, "rb") as f:
        vectorizer = pickle.load(f)
    return vectorizer


def load_labels(language: str):
    # TODO: Create a pkl file that saves the labels together with the model and load them here, instead of
    #  hardcoding them
    if language == ENGLISH:
        return ENGLISH_SOFTSKILLS
    
    elif language == FRENCH:
        return FRENCH_SOFTSKILLS
    else:
        raise ValueError("Check language. Only French and English allowed.")


def sigmoid(list_of_values: list):
    return [np.round(2 / (1 + np.exp(-x)) - 1, 2) for x in list_of_values]


def soft_skills_maping():

    en_to_fr = EN_TO_FR
    fr_to_en = {v: k for k, v in en_to_fr.items()}

    return en_to_fr, fr_to_en


def predict_soft_skills_multitext(language: str, input_texts: list, model,
                                  vectorizer: CountVectorizer):
    """
    Input
    ----------
    language: english or french
    input_texts: list of texts from each resume.
    vectorizer: CounteVectorizer class

    Output
    -------
    predicted_labels: list of predicted labels for each text.
    relevant_probs: list of predicted probabilities for each predicted label.
    relevant_sentences: list of relevant sentences that have predicted label, as the prediction could be empty,
                        the empty sentences are being ignored.
    relevant_indices: list of relevant indices associated with the relevant sentence and the corresponding resume.
    """
    labels = load_labels(language)
    id2label = {idx: label for idx, label in enumerate(labels)}
    resume_lines_list = [preprocess_resume(input_text, language) for input_text in input_texts]
    # Flatten the list of resume lines
    resume_lines = [line for rl in resume_lines_list for line in rl]
    # Keep track of indices after flattening
    resume_indices = [i for (i, rl) in enumerate(resume_lines_list) for _ in rl]
    vectorized_text_lines = vectorizer.transform(resume_lines)
    prediction_probs = model.decision_function(vectorized_text_lines)
    positive_prediction_probs = [[value for value in row if value > 0] for row in np.round(prediction_probs, 2)]
    relevant_sentences = []
    relevant_probs = []
    relevant_indices = []
    predicted_labels = []
    for (index_count, sample) in enumerate(prediction_probs):
        if np.all(sample < 0):
            continue
        predicted_labels.append([id2label[idx] for idx, label in enumerate(sample) if label > 0])
        relevant_sentences.append(resume_lines[index_count])
        relevant_probs.append(positive_prediction_probs[index_count])
        relevant_indices.append(resume_indices[index_count])
    relevant_probs_sigmoid = [sigmoid(prediction_prob_list) for prediction_prob_list in relevant_probs]
    return predicted_labels, relevant_probs_sigmoid, relevant_sentences, relevant_indices


def get_soft_skills_from_single_lang_df(resume_df: pd.DataFrame, language: str, model, vectorizer: CountVectorizer):
    """
    Input
    ----------
    resume_df: a dataframe that contains resume information only in one particular language.
    language: english or french. ("en" or "fr").
    model: model for the corresponding language.
    vectorizer: vectorizer for the corresponding language.

    Output
    -------
    soft_skills_dict: : a dictionary with the soft skills for each CV in the dataframe. It has the following form:
        {
            1: {
                    'softSkills': [[{'leadership': 0.53, 'sentence': '...'}],
                                   [{'leadership': 0.45, 'time management': 0.06, 'sentence': '...'}]]
            2: {
                    'softSkills': [[{'leadership': 0.45, 'sentence': '...'}],
                                    [{'problem solving': 0.4, 'teamwork': 0.46, 'sentence': '...'}]
                                    [{'technical': 0.62, 'sentence': '...'}],
                                    [{'technical': 0.38, 'sentence': '...}]]
                }
      }
    """
    assert df_has_correct_types(resume_df, RESUME_FIELDS), "Expected dataframe does not have correct types."
    soft_skills_dict = {}
    labels, probs, sentences, indices = predict_soft_skills_multitext(language, 
                                                                      resume_df[RESUME_FIELDS.resume_field], 
                                                                      model, 
                                                                      vectorizer)
    for (labels, scores, sentence, i) in zip(labels, probs, sentences, indices):
        id = resume_df[RESUME_FIELDS.id_field].iloc[i]
        soft_skills_dict[id] = soft_skills_dict.get(id, {'softSkills': []})
        label_dict = dict(zip(labels, scores))
        label_dict['sentence'] = sentence
        for key in LABELS_TO_EXCLUDE:
            if key not in label_dict:
                continue
            del label_dict[key]
        soft_skills_dict[id]['softSkills'].append([label_dict])
    id_with_no_skill = set(resume_df['ResumeID'].values) - set(soft_skills_dict.keys())
    for id in id_with_no_skill:
        soft_skills_dict[id] = {'softSkills': []}
    return soft_skills_dict


def transform_soft_skills_dict(soft_skills_result: dict, language: str, return_sentences: bool = False):
    """
    Input
    ----------
    soft_skills_result: a dictionary with the soft skills for each CV. It has the following form:
        {
            1: {
                    'softSkills': [[{'leadership': 0.53, 'sentence': '...'}],
                                   [{'leadership': 0.45, 'time management': 0.06, 'sentence': '...'}]]
            2: {
                    'softSkills': [[{'leadership': 0.45, 'sentence': '...'}],
                                    [{'problem solving': 0.4, 'teamwork': 0.46, 'sentence': '...'}]
                                    [{'technical': 0.62, 'sentence': '...'}],
                                    [{'technical': 0.38, 'sentence': '...}]]
                }
        }
    language: english or french

    Output
    -------
    new_soft_skills_result: a dictionary with the soft skills for each CV with a different format:
    {
        1: {'softSkills': [{'name': 'leadership',
                     'score': 0.31,
                     'sentences': ['sentence1', 'sentence2']},
                    {'name': 'problem solving',
                     'score': 0.29,
                     'sentences': ['sentence3']},
                    {'name': 'teamwork',
                     'score': 0.2,
                     'sentences': ['sentence3']},
                    {'name': 'time management',
                     'score': 0.2,
                     'sentences': ['sentence2']}]},
        2: {'softSkills': [{'name': 'leadership',
                     'score': 0.25,
                     'sentences': ['sentence1']},
                    {'name': 'problem solving',
                     'score': 0.24,
                     'sentences': ['sentence2']},
                    {'name': 'teamwork',
                     'score': 0.25,
                     'sentences': ['sentence2']},
                    {'name': 'technical',
                     'score': 0.26,
                     'sentences': ['sentence3', 'sentence4']}]}
    }
    """
    new_soft_skills_result = {key: None for key in soft_skills_result.keys() if key != 'sentence'}
    labels = load_labels(language)
    for key, value in soft_skills_result.items():
        soft_skills = value['softSkills']
        transformed_skills = []
        for label in labels:
            dict_for_current_label = {'name': None, 'score': None}
            scores_for_current_label = []
            sentences_for_current_label = []
            for skill_list in soft_skills:
                skill_dict = skill_list[0]
                if skill_dict.get(label) is None:
                    continue
                scores_for_current_label.append(skill_dict.get(label))
                sentences_for_current_label.append(skill_dict.get('sentence'))
            if not scores_for_current_label:
                continue
            dict_for_current_label['name'] = label
            dict_for_current_label['score'] = np.round(mean(sorted(scores_for_current_label, reverse=True)[:5]), 2)
            if return_sentences:
                dict_for_current_label['sentences'] = sentences_for_current_label
            transformed_skills.append(dict_for_current_label)
        new_soft_skills_result[key] = {'softSkills': transformed_skills}

    return new_soft_skills_result


def complete_missing_soft_skills(current_soft_skills: dict, language: str, return_sentences: bool = False):
    """
    This function takes as input the softskills per resume in a dictionary and returns the same dictionary with
    additional softskills added if they are missing.
    Input:
    current_soft_skills : {
        1: {'softSkills': [{'name': 'leadership', 'score': 0.31, 'sentences': ['sentence1', 'sentence2']},
                            {'name': 'problem solving', 'score': 0.29, 'sentences': ['sentence3']},
                            {'name': 'teamwork', 'score': 0.2, 'sentences': ['sentence3']},
                            {'name': 'time management', 'score': 0.2, 'sentences': ['sentence2']}]},
        2: {'softSkills': [{'name': 'leadership', 'score': 0.25, 'sentences': ['sentence1']},
                            {'name': 'problem solving', 'score': 0.24, 'sentences': ['sentence2']},
                            {'name': 'teamwork', 'score': 0.25, 'sentences': ['sentence2']},
                            {'name': 'technical', 'score': 0.26,'sentences': ['sentence3', 'sentence4']}
                            ]}
    }
    language: en or fr
    return_sentences: True or False.

    Output:
    completed_soft_skills = {
        1: {'softSkills': [{'name': 'leadership', 'score': 0.31, 'sentences': ['sentence1', 'sentence2']},
                            {'name': 'problem solving', 'score': 0.29, 'sentences': ['sentence3']},
                            {'name': 'teamwork', 'score': 0.2, 'sentences': ['sentence3']},
                            {'name': 'time management', 'score': 0.2, 'sentences': ['sentence2']},
                            {'name': 'autonomy', 'score': 0.0, 'sentences': []},
                            {'name': 'communication', 'score': 0.0, 'sentences': []},
                            {'name': 'creativity', 'score': 0.0, 'sentences': []},
                            {'name': 'work ethics', 'score': 0.0, 'sentences': []},
                            {'name': 'motivation', 'score': 0.0, 'sentences': []},
                        ]},
        2: {'softSkills': [{'name': 'leadership', 'score': 0.25, 'sentences': ['sentence1']},
                            {'name': 'problem solving', 'score': 0.24, 'sentences': ['sentence2']},
                            {'name': 'teamwork', 'score': 0.25, 'sentences': ['sentence2']},
                            {'name': 'autonomy', 'score': 0.26, 'sentences': ['sentence3', 'sentence4']}
                            {'name': 'time management', 'score': 0.0, 'sentences': []},
                            {'name': 'communication', 'score': 0.0, 'sentences': []},
                            {'name': 'creativity', 'score': 0.0, 'sentences': []},
                            {'name': 'work ethics', 'score': 0.0, 'sentences': []},
                            {'name': 'motivation', 'score': 0.0, 'sentences': []},
                        ]}
        }
        """
    labels = load_labels(language)
    updated_labels = [label for label in labels if label not in LABELS_TO_EXCLUDE]
    completed_soft_skills = {k: {'softSkills': []} for k in current_soft_skills.keys()}
    for resume_id, softskills_dict in current_soft_skills.items():
        soft_skills_list = softskills_dict["softSkills"]
        current_soft_skills = [soft_skill['name'] for soft_skill in soft_skills_list]
        for label in updated_labels:
            if label in current_soft_skills:
                continue
            if return_sentences:
                soft_skills_list.append({'name': label, 'score': 0.0, 'sentences': []})
            else:
                soft_skills_list.append({'name': label, 'score': 0.0})
        completed_soft_skills[resume_id]['softSkills'] = soft_skills_list
    return completed_soft_skills


def get_soft_skills_from_df(resume_df: pd.DataFrame, models, vectorizers: CountVectorizer, language: str = ENGLISH,
                            return_sentences: bool = False):
    """
    Input
    ----------
    resume_df: a dataframe with resumes in english and french.
    models: a dictionary with models for the two languages {"english": model_en, "french": model_fr}
    vectorizers: a dictionary with vectorizers for the two languages {"english": model_en, "french": model_fr}

    Output
    -------
    result: a dictionary with the soft skills for each CV. It has the following form:
            {0: {'softSkills': [{'name': 'autonomy', 'score': 0.05},
                                {'name': 'leadership', 'score': 1.0},
                                {'name': 'problem solving', 'score': 0.26},
                                {'name': 'teamwork', 'score': 0.42},
                                {'name': 'time management', 'score': 0.16},
                                {'name': 'communication', 'score': 0.0},
                                {'name': 'creativity', 'score': 0.0},
                                {'name': 'work ethics', 'score': 0.0}]},
            1: {'softSkills': [{'name': 'autonomy', 'score': 0.3},
                                {'name': 'communication', 'score': 0.68},
                                {'name': 'leadership', 'score': 0.18},
                                {'name': 'problem solving', 'score': 0.67},
                                {'name': 'teamwork', 'score': 0.99},
                                {'name': 'time management', 'score': 0.08},
                                {'name': 'creativity', 'score': 0.0},
                                {'name': 'work ethics', 'score': 0.0}], ...}
    """
    resume_df_en = resume_df[resume_df[RESUME_FIELDS.language_field] == ENGLISH]
    resume_df_fr = resume_df[resume_df[RESUME_FIELDS.language_field] == FRENCH]
    result = {}
    en_to_fr, fr_to_en = soft_skills_maping()

    if len(resume_df_en) > 0:
        result_en = get_soft_skills_from_single_lang_df(resume_df_en, ENGLISH, models[ENGLISH],
                                                        vectorizers[ENGLISH])
        transformed_result_en = transform_soft_skills_dict(result_en, ENGLISH, return_sentences)

        if language == FRENCH:
            for resume_index, softskills_dct in transformed_result_en.items():
                soft_skills_lst = softskills_dct["softSkills"]
                for soft_skills_dct2 in soft_skills_lst:
                    soft_skills_dct2["name"] = en_to_fr[soft_skills_dct2["name"]]

        transformed_result_en = complete_missing_soft_skills(transformed_result_en, language, return_sentences)
        result.update(transformed_result_en)
    if len(resume_df_fr) > 0:
        result_fr = get_soft_skills_from_single_lang_df(resume_df_fr, FRENCH, models[FRENCH],
                                                        vectorizers[FRENCH])
        transformed_result_fr = transform_soft_skills_dict(result_fr, FRENCH, return_sentences)

        if language == ENGLISH:
            for resume_index, softskills_dict in transformed_result_fr.items():
                soft_skills_list = softskills_dict["softSkills"]
                for soft_skills_dict2 in soft_skills_list:
                    soft_skills_dict2["name"] = fr_to_en[soft_skills_dict2["name"]]
        
        transformed_result_fr = complete_missing_soft_skills(transformed_result_fr, language, return_sentences)
        result.update(transformed_result_fr)
    return result
