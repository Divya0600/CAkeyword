
def get_skill_score(resumes_skill_count_dict: dict, job_desc_skill_count_dict: dict):
    """

    Input
    ----------
    resumes_skill_count_dict: a dictionary of dictionaries with the skills appearing in each resume.
    job_desc_skill_count_dict: a dictionary with the skill counts appearing in the job description

    Output
    -------
    skill_score_dict: a dictionary of resumes ids and skill score for each resume.
    """
    all_common_skills = []
    skill_score_dict = {}
    for resume_id in resumes_skill_count_dict:
        current_resume_skill_ids_count_dict = resumes_skill_count_dict[resume_id]
        common_skills_between_resume_and_job_desc = \
            set(current_resume_skill_ids_count_dict.keys()).intersection(job_desc_skill_count_dict.keys())
        number_of_common_skills = len(common_skills_between_resume_and_job_desc)
        all_common_skills.append((resume_id, number_of_common_skills))
    if not all_common_skills:
        for resume_id in resumes_skill_count_dict:
            skill_score_dict[resume_id] = 0.0
        return skill_score_dict
    max_job_desc_resumes_common_skills = max([pair[1] for pair in all_common_skills])
    if max_job_desc_resumes_common_skills == 0:
        for resume_id in resumes_skill_count_dict:
            skill_score_dict[resume_id] = 0.0
        return skill_score_dict
    skill_score_dict = {pair[0]: round(pair[1]/max_job_desc_resumes_common_skills, 2) for pair in all_common_skills}
    return skill_score_dict
