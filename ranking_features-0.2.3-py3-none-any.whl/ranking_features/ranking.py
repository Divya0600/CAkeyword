import numpy as np
import pandas as pd
import scipy
from ranking_features.similarity_scoring import get_semantic_similarity_score, get_similarity, get_top_words
from ranking_features.keyword_extraction import compute_tfidf, extract_keywords, extract_from_resume_df, \
    to_sparse_matrix, KeywordCountVectorizer
from ranking_features.utils import detect_language, ResumeDataFrameFields, KeywordDataFrameFields
from ranking_features.skill_score import get_skill_score
from ranking_features.clustering import get_clusters


def extract_keywords_with_selection(text: str, vectorizer: KeywordCountVectorizer, selection: list):
    """
    Extract keywords from a text, taking into account the selection of keyword provided. Returns a dict of keyword
    counts, with only the keywords that are part of the selection in it. If some keywords in the selection are not
    extracted from the text, they will be added to the count dict with a value of 1.

    Args:
        text (str): Text to extract keywords from.
        vectorizers (dict(KeywordCountVectorizer)): A dictionariy with two keys: 'fr' and 'en'. The values of those
        two keys are initialized KeywordCountVectorizer objects, with the corresponding language.
        selection (list): List of keyword IDs selected.

    Returns:
        (dict): dict with each keyword count
    """
    count_dict = extract_keywords(
        docs=text, vectorizer=vectorizer, return_counts=True)
    # Remove keywords that are not in selection
    count_dict = {
        k: v for k, v in count_dict.items() if k in selection}
    # Add keywords that are in selection but not extracted   
    added_keywords = [keyword_id for keyword_id in selection if keyword_id not in count_dict]
    for keyword_id in added_keywords:
        count_dict[keyword_id] = 1
    return count_dict


def get_experience_score(job_desc_text: str, job_desc_vector: scipy.sparse.csr_matrix,
        resume_dict: dict, resume_vectors: scipy.sparse.csr_matrix, row2id: dict,
        lda_model, lda_weight: float = 0.25, semantic_weight: float = 0.75):
    """
    Get experience score, which is a combination of LDA similarity and semantic similarity.

    Args:
        job_desc_text (str): Text of the job description.
        job_desc_vector (scipy.sparse.csr_matrix): Sparse vector of keyword count for the job description
        resume_dict (dict): Dictionary with keys as resumes ids and values as resume text
        resume_vectors (scipy.csr_matrix): Sparse matrix of keyword count for resumes
        row2id (dict): Mapping from row of the resume_vectors to the corresponding resume ID.
        lda_model (sklearn model): Model to use for the LDA similarity
        lda_weight (float): Weight of the lda similarity. Must add up to 1 with semantic_weight
        semantic_weight (float): Weight of the semantic similarity. Must add up to 1 with lda_weight

    Returns:
        (dict): dict with keys as resumes ids and values as experience score
    """    
    assert lda_weight + semantic_weight == 1, "LDA & semantic weights should add up to 1"
    assert len(resume_dict) == resume_vectors.shape[0], "Size mismatch between resume dict and resume vectors"
    if lda_weight > 0:
        job_desc_lda_vector = lda_model.transform(job_desc_vector)
        resume_lda_matrix = lda_model.transform(resume_vectors)
        lda_similarity = get_similarity(job_desc_lda_vector, resume_lda_matrix, row2id)
    else:
        lda_similarity = 0
    
    semantic_similarity = get_semantic_similarity_score(resume_dict, job_desc_text) if semantic_weight > 0 else 0
    
    experience_score = lda_weight * lda_similarity + semantic_weight * semantic_similarity
    return experience_score.to_dict()


def get_global_score(skill_score_dict: dict, experience_score_dict: dict, skill_weight: float = 0.6,
                     experience_weight: float = 0.4):
    """
    Get global score, which is a skill score and experience score.

    Args:
        skill_score_dict (dict): Dictionary with keys as resumes ids and values as skill score
        experience_score_dict (dict): Dictionary with keys as resumes ids and values as experience score
        skill_weight (float): Weight of the skill score. Must add up to 1 with semantic_weight
        experience_weight (float): Weight of the experience score. Must add up to 1 with lda_weight

    Returns:
        (dict): dict with keys as resumes ids and values as global score
    """    
    assert skill_weight + experience_weight == 1, "Skill & experience score weights should add up to 1"
    ids = set(skill_score_dict.keys()).union(set(experience_score_dict.keys()))
    global_score = {
        idx: skill_weight*skill_score_dict.get(idx, 0) + experience_weight*experience_score_dict.get(idx, 0)
        for idx in ids
    }

    return global_score


def rank_candidates(job_description: str, resume_df: pd.DataFrame, resume_df_fields: ResumeDataFrameFields,
                    selected_skill_ids: list, selected_job_title_ids: list, job_skill_df: pd.DataFrame,
                    job_skill_df_fields: KeywordDataFrameFields, job_skill_vectorizers: KeywordCountVectorizer,
                    lda_model, lda_model_skills, experience_weights={}, global_weights={}):
    """
    Get global score, skill score, experience score and top skills for candidates based on provided job description.

    Args:
        job_description (str): Text of the job description.
        resume_df (pd.Dataframe): Dataframe containing resumes and their corresponding IDs.
        resume_df_fields (ResumeDataFrameFields): Name of the expected columns in resume_df.
        job_skill_df_fields (KeywordDataFrameFields): Name of the expected columns in job_skill_df
        selected_skill_ids (list): List of selected skill keyword IDs.
        selected_job_title_ids (list): List of selected job title keyword IDs.
        job_skill_df (pd.DataFrame): pandas dataframe with ID, job or skill names in French and English and IDF values.
        job_skill_vectorizers (dict(KeywordCountVectorizer)): A dictionary with two keys: 'fr' and 'en'. The values of
        those two keys are initialized KeywordCountVectorizer objects, to extract job and skill keywords in
        the corresponding language.
        lda_model (sklearn model): Model to use for the LDA similarity
        experience_weights (dict): Weights for the experience score. Format should be {'lda_weight': ..., 'semantic_weight': ...}. 
            If not specified, default weights are used.
        global_weights (dict): Weights for the global score. Format should be {'skill_weight': ..., 'experience_weight': ...}
                If not specified, default weights are used.
    Returns:
        global_score, skill_score_dict, experience_score_dict, top_skills
    """
    select_ids = selected_job_title_ids + selected_skill_ids
    language = detect_language(job_description)
    job_desc_skill_job_count_dict = extract_keywords_with_selection(job_description, job_skill_vectorizers[language],
                                                                    select_ids)
    
    resume_df[resume_df_fields.language_field] = resume_df[resume_df_fields.resume_field].apply(detect_language)
    job_skill_count_dict = extract_from_resume_df(resume_df, resume_df_fields, job_skill_vectorizers,
                                                  return_counts=True)

    job_skill_count_matrix, job_skill_row2id, resume_job_skill_col2id = to_sparse_matrix(job_skill_count_dict,
                                                                                          job_skill_df,
                                                                                          job_skill_df_fields)

    job_desc_job_skill_vector, _, job_skill_col2id = to_sparse_matrix(job_desc_skill_job_count_dict, job_skill_df,
                                                                        job_skill_df_fields, resumes_dict=False)
    assert resume_job_skill_col2id == job_skill_col2id, "Mismatch between count matrices of resume and job description"

    skill_score_dict = {}
    top_skills = {}

    skills_df = job_skill_df[job_skill_df[job_skill_df_fields.id_field].str.contains('S')]
    skill_count_dict = {resume_id: {k: v for k, v in d.items() if 'S' in k}
                        for resume_id, d in job_skill_count_dict.items()}
    skill_count_matrix, skill_row2id, resume_skill_col2id = to_sparse_matrix(skill_count_dict,
                                                                            skills_df,
                                                                            job_skill_df_fields)
    job_desc_skill_count_dict = {k: v for k, v in job_desc_skill_job_count_dict.items() if 'S' in k}

    idf_skill = np.zeros((skill_count_matrix.shape[1], skill_count_matrix.shape[1]))
    unique_skills = skills_df[[job_skill_df_fields.id_field, job_skill_df_fields.idf_field]].drop_duplicates()
    idf_dict = unique_skills[[job_skill_df_fields.id_field, job_skill_df_fields.idf_field]]\
        .set_index(job_skill_df_fields.id_field).to_dict()[job_skill_df_fields.idf_field]
    for col, skill_id in resume_skill_col2id.items():
        idf_skill[col, col] = idf_dict[skill_id]

    skill_score_dict = get_skill_score(
        resumes_skill_count_dict=skill_count_dict, job_desc_skill_count_dict=job_desc_skill_count_dict)
    skill_tfidf = compute_tfidf(skill_count_matrix, idf_skill)
    top_skills = get_top_words(matched_keyword_ids=selected_skill_ids, resumes_tfidf_matrix=skill_tfidf,
                               col2id=resume_skill_col2id, row2id=skill_row2id)

    resume_dict = resume_df[[resume_df_fields.id_field, resume_df_fields.resume_field]]\
        .set_index(resume_df_fields.id_field).to_dict()[resume_df_fields.resume_field]
    
    experience_score_dict = get_experience_score(
        job_desc_text=job_description, job_desc_vector=job_desc_job_skill_vector,
        resume_dict=resume_dict, resume_vectors=job_skill_count_matrix, row2id=job_skill_row2id,
        lda_model=lda_model, **experience_weights)

    clusters = get_clusters(lda_model_skills, skill_count_matrix, job_skill_row2id)
    global_score = get_global_score(skill_score_dict, experience_score_dict, **global_weights)
    return global_score, skill_score_dict, experience_score_dict, top_skills, clusters
