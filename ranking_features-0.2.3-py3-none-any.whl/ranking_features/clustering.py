import numpy as np
import pandas as pd
from scipy import sparse
from ranking_features.utils import SKILLS_DF_FIELDS, df_has_correct_types, KeywordDataFrameFields


def get_cluster_info(clusters: dict, top_candidate_ids: list, skills_df: pd.DataFrame, lda_model,
                     skills_df_fields: KeywordDataFrameFields = SKILLS_DF_FIELDS):
    """
    Summarizes cluster information in a list of dictionaries.

    Parameters
    ----------
    clusters: a dictionary of candidate with ids as keys and cluster ids as values.
    top_candidate_ids: list of candidate ids.
    skills_df: pandas dataframe of skills.
    lda_model: trained topic model.
    skills_df_fields: column names for skills_df

    Returns
    -------
    A list of dictionaries, one dictionary for each clustering, containing the id, candidates
    corresponding to the cluster and the topics associated with each cluster.
    """
    assert df_has_correct_types(skills_df, skills_df_fields), "Expected dataframe does not have correct types."
    cluster_info = []
    for cluster_id in np.unique(list(clusters.values())):
        members = [k for k, v in clusters.items() if v == cluster_id and k in top_candidate_ids]
        if len(members) == 0:
            continue
        top_topics = [
            skills_df.loc[skills_df[skills_df_fields.id_field] == str(i), skills_df_fields.eng_name_field].values[0]
            for i in lda_model.components_[cluster_id].argsort()[:-11:-1]]
        cluster_info.append({'clusterID': int(cluster_id), 'candidates': [{'id': member_id} for member_id in members],
                             'topics': top_topics})
    return cluster_info


def get_clusters(lda_model, jobgroup_subset: sparse.csr_matrix, subset_row2id: dict):
    """
    Provides the cluster (the topic group with the highest probability) of each CV.

    Args:
    lda_model(SKlearn.decomposition._lda): 
        Pre-trained LDA model for topic modeling
    jobgroup_subset(scipy.sparse):
        Sparse matrix of the subset of the CVs that are selected for a particular job description.
    subset_row2id (dict):
        Should be of format {sparse_matrix_row_index: ResumeID, sparse_matrix_row_index: ResumeID, ..}
        Dictionary linking the sparse matrix's rows to the ResumeIDs.

    Returns:
    dict:
        Dictionary linking the ResumeIDs to the associated cluster ID
    """
    
    subset_topic = lda_model.transform(jobgroup_subset)
    return {subset_row2id[k]: np.argmax(subset_topic[k]) for k, _ in enumerate(subset_topic)}


def get_top_topics(input_df: pd.DataFrame, keywords_fields: KeywordDataFrameFields, model, n_top_words: list):
    """
    Parameters
    ----------
    input_df: dataframe used for the model.
    keywords_fields: KeywordDataFrameFields with column names for input_df
    model: LDA model
    n_top_words: number of top features returned per topic

    Returns
    -------
    topic_names: list of tuples containing (topic_index, (feature_related_to_topic, feature_related_to_topic,...))
    """
    topic_names = []
    list_unique_ids = np.unique(input_df[keywords_fields.id_field]).tolist()
    col2id = {i: unique_id for i, unique_id in enumerate(list_unique_ids)}
    for topic_idx, topic in enumerate(model.components_):
        top_features_ind = topic.argsort()[:-n_top_words - 1:-1]
        top_features = [input_df.loc[input_df[keywords_fields.id_field] == col2id[i],
                                     keywords_fields.eng_name_field].values[0] for i in top_features_ind]
        topic_names.append((topic_idx, tuple(top_features)))
    return topic_names
