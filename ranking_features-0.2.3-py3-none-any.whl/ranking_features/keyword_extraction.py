import pandas as pd
import numpy as np
from scipy import sparse
from sklearn.feature_extraction.text import CountVectorizer
from typing import Union
import spacy
from ranking_features.utils import KeywordDataFrameFields, df_has_correct_types, ENGLISH, FRENCH, JOB_SKILL_FIELDS, \
    RESUME_FIELDS


class KeywordCountVectorizer(CountVectorizer):
    """This class applies a sklearn CountVectorizer while taking into account the fact that one keyword ID might match
    multiple keywords.

    Attributes:
        keywords_df (DataFrame): DataFrame of keywords.
        df_fields (KeywordDataFrameFields): List of fields for the keywords DataFrame.
        ngram_range (tuple): Range for ngram sizes.
        language (str): The language ('en' for English and 'fr' for French) used for keyword matching.
        vocabulary (list): List of unique keywords to track from 'keywords_df'.

    Methods:
        __init__(keywords_df: DataFrame, df_fields: list, language: str, **params): Initializes the
        KeywordCountVectorizer object.
        transform_and_merge(docs: list): Transforms a list of documents and merges resulting keyword columns by
        keyword ID.
        format_merged_matrix(count_matrix: list, return_counts: bool, use_kw_names: bool): Formats count matrix into a
        dictionary..

    Note:
        By default, just like in CountVectorizer, lowercase = True, which means if you pass case-sensitive keywords,
        it will be lowercased."""

    def __init__(self, keywords_df, df_fields, language, **params):

        super(KeywordCountVectorizer, self).__init__(
            **params
        )

        self.language = language
        self.df_fields = df_fields
        self.keywords_df = keywords_df.copy().sort_values(by=self.df_fields.id_field)
        # lowercase all the keywords
        if self.lowercase:
            self.keywords_df[self.df_fields.eng_name_field] = self.keywords_df[
                self.df_fields.eng_name_field
            ].str.lower()
            self.keywords_df[self.df_fields.fr_name_field] = self.keywords_df[
                self.df_fields.fr_name_field
            ].str.lower()

        tokenizer = self.build_tokenizer()

        for column_name in [self.df_fields.eng_name_field, self.df_fields.fr_name_field]:
            self.keywords_df[column_name] = self.keywords_df[column_name].apply(lambda keyword: ' '.join(token for token in tokenizer(keyword)))

        if language == ENGLISH:
            # we create a list of vocabulary
            self.vocabulary = list(self.keywords_df[df_fields.eng_name_field].unique())
            # for each keyword, there might be more than one keyword ID associated with it, due to the way we handled
            # translations + case-sensitiveness
            # Here, we get a small pd.Series with the list of keyword ID associated with each words
            self.col_to_id = (
                self.keywords_df.groupby(self.df_fields.eng_name_field)[self.df_fields.id_field].unique().apply(list))
            # For each word, we get the vocabulary list's index
            self.col_to_id.index = self.col_to_id.index.map(
                lambda name: self.vocabulary.index(name)
            )
        elif language == FRENCH:
            # With French, we combine both the English and the French keywords, as French people will often use
            # English keywords in their resumes
            vocabulary_fr = set(self.keywords_df[df_fields.fr_name_field].unique())
            vocabulary_en = set(self.keywords_df[df_fields.eng_name_field].unique())
            self.vocabulary = list(vocabulary_en.union(vocabulary_fr))

            col_to_id_en = (self.keywords_df.groupby(df_fields.eng_name_field)[df_fields.id_field].unique().apply(list))
            col_to_id_en.index = col_to_id_en.index.map(lambda name: self.vocabulary.index(name))
            # Reindex and fillna ensures that we have the full list of vocabulary keywords. list('') gives us [],
            # which is what we want.
            col_to_id_en = (col_to_id_en.reindex(range(len(self.vocabulary))).fillna("").apply(list))

            col_to_id_fr = (self.keywords_df.groupby(df_fields.fr_name_field)[df_fields.id_field].unique().apply(list))
            col_to_id_fr.index = col_to_id_fr.index.map(lambda name: self.vocabulary.index(name))
            col_to_id_fr = (col_to_id_fr.reindex(range(len(self.vocabulary))).fillna("").apply(list))

            # We add the French and English lists together. By applying set, we ensure that the result has no
            # duplicates.
            self.col_to_id = col_to_id_fr + col_to_id_en
            self.col_to_id = self.col_to_id.apply(set).apply(list)
        else:
            raise ValueError("Check language. Only French and English allowed.")

        # The final result for col_to_id is a pd.Series where the self.vocabulary indices are the indices of col_to_id,
        # and the values are the keyword indices (from keywords_df)
        # associated with that vocabulary word.
        self.col_to_id = self.col_to_id.sort_index()
        self.col_to_id.index.rename("Vocabulary index", inplace=True)
        self.col_to_id.rename("keywords_df row location number", inplace=True)

        # We get the biggest ngram size in the vocabulary list.
        biggest_ngram = (
            pd.Series(self.vocabulary).str.split(' ').str.len().max()
        )  # Since we space-join for the CountVectorizer parent class (this is what is expected for the vocabulary), using split(' ') will give us the right number of ngrams.
        self.ngram_range = (1, biggest_ngram)

    def transform_and_merge(self, docs: list):
        """
        Applies the vectorizer on a list of documents, and merge the resulting keyword columns corresponding to
        the same keyword id.

        Args:
        docs(list(str)): List of text documents to be analyzed.
        Returns:
        (sparse.csr): Sparse matrix where each row corresponds to the document index in the docs list, and each columns
        correspond to the position of the keyword ID when sorted in keywords_df.
        
        WARNING: This does not correspond to the same output as to_sparse_matrix. To get the expected behavior,
        you should use the functions extract_keywords and extract_from_resume_df.

        """

        # Use the transform method inherited from sklearn's CountVectorizer
        output = self.transform(docs)

        # Turning the sparse matrix into a dataframe. Usually, we would want to avoid this, but it makes things much
        # simpler and doesn't cost much with the sizes we're talking about. For a large amount of documents,
        # the self.transform line above takes the most time by far.
        # The columns are the vocabulary list indices, and the rows represent the documents (resumes, job description)
        # in the order they were given.
        count_df = pd.DataFrame(output.toarray())

        # We transpose the DataFrame to get the rows to be the vocabulary. We repeat the rows for vocabulary used for
        # multiple keyword IDs (for example, a French word might be used as a translation for multiple English words,
        # and so one single word will have multiple keyword IDs.)
        # Repeating it like this ensures that the keyword IDs in the concatenation of col_to_id will perfectly
        # line up with the right vocabulary words
        # This is all done to avoid a for loop
        repeated_count_df = pd.DataFrame(count_df.T.values.repeat(self.col_to_id.apply(len), axis=0),
                                         columns=count_df.T.columns)

        # We groupby the concatenated col_to_id. We have exactly the same number in the concatenated array as
        # the number of rows in repeated_count_df. The behavior of groupby is different when you have a list or array
        # of exactly the number of rows.
        # Documentation for this behavior: If a list or ndarray of length equal to the selected axis is passed
        # (see the groupby user guide),
        # the values are used as-is to determine the groups. A label or list of labels may be passed to group by
        # the columns.
        # For example, if we have the np.concatenate(self.col_to_id) = [1,5,7,6,...,300,2003,7],
        # then the third row will be in group 7 along with the last row,
        # and they will be added up, because they both correspond to keyword ID 7.
        merged_matrix = repeated_count_df.groupby(np.concatenate(self.col_to_id)).sum().sort_index().values.T

        # Finally, we turn the result into a sparse matrix.
        merged_matrix = sparse.csr_matrix(merged_matrix)

        # The result is a sparse matrix where the rows are the documents (in order) and the columns correspond to the
        # order of the keywords in the keywords dataframe when sorting by id_field.
        # WARNING: The rows do not correspond to a resume ID, they correspond to the order in which the documents
        # were sent in the docs list.
        return merged_matrix

    def format_merged_matrix(self, merged_matrix: sparse.csr_matrix, row2id: dict, return_counts: bool = False,
                             use_kw_names: bool = False):
        """
        Format count matrix into a dictionary of dictionary, or a dictionary of lists, depending on whether counts
        need to be returned or not.

        Args:
        merged_matrix (sparse.csr): Sparse matrix, output of CountVectorizer.transform(resumes). Columns correspond
        to keywords while rows correspond to resumes. WARNING: This is expected to be the output of transform_and_merge.
        row2id (dict): Dictionary that maps the row number of the matrix to the resume ID.
        return_counts (bool, optional): Set to true to return the keyword occurrence counts. Defaults to False.
        use_kw_names (bool, optional): Set to true to use the keyword names instead of the IDs. If multiple keyword
        names for one ID, will use the first in the keywords_df. (This is just for debugging)

        Returns:
        (dict): Dictionary where the keys are the index number of the document list, and the values are either lists
        of keyword IDs, or dictionaries of keyword IDS: count.
                These IDs are derived from self.keywords_df.
        """
        output = {}

        column_names = self.keywords_df.drop_duplicates(
            subset=[self.df_fields.id_field]
        )[self.df_fields.id_field].values
        merged_df = pd.DataFrame(merged_matrix.toarray().astype(int), columns=column_names)
        if return_counts:
            for index, row in merged_df.iterrows():
                resume_id = row2id[index]
                output[resume_id] = row[row > 0].to_dict()
        else:
            for index, row in merged_df.iterrows():
                resume_id = row2id[index]
                output[resume_id] = list(row[row > 0].index)
        if use_kw_names:
            output = {k: ids2text(k_dict, self.keywords_df, self.df_fields, self.language) for
                      k, k_dict in output.items()}
            return output
        return output


def extract_keywords(docs: Union[str, list], vectorizer: KeywordCountVectorizer, row2id: Union[dict, None] = None,
                     return_counts: bool = False,use_kw_names: bool = False, as_matrix: bool = False):
    """
    Extract keywords from a text or a list of texts. Returns the list of keywords found or a dict with each
    keyword count, as needed.

    Args:
        docs (str | list(str)): Text(s) to extract the keywords from.
        vectorizer (KeywordCountVectorizer): Initialized KeywordCountVectorizer object, with the appropriate
        vocabulary and language.
        row2id (dict, optional): A mapping of the row position and the document ID. Needs to be the same size as
        the number of documents provided.
                                If None, will simply ID the documents in order from 0 to N-1.
        return_counts (bool, optional): Set to true to return the keyword occurrence counts. Defaults to False.
        use_kw_names (bool, optional): Set to true to use the keyword names instead of the IDs.
        as_matrix (bool, optional): Set to true to return the output as a matrix.

    Returns:
        (list, dict or matrix): List of IDs of the keywords found or a dict with each keyword count,
         depending on return_counts, or a matrix if as_matrix=True, and if a string was passed
         instead of a list as 'docs'.

    # WARNING: When as_matrix is True, the output is not the same as the one from to_spare_matrix function.
    """

    if type(docs) == str:
        merged_matrix = vectorizer.transform_and_merge([docs])
        if row2id is None:
            row2id = {0: str(0)}
    else:
        merged_matrix = vectorizer.transform_and_merge(docs)
        if row2id is None:
            row2id = {i: str(i) for i in range(len(docs))}

    if as_matrix:
        return merged_matrix
    
    output = vectorizer.format_merged_matrix(
        merged_matrix, row2id, return_counts, use_kw_names
    )
    if type(docs) == str:
        return output[row2id[0]]
    else:
        return output
    

def extract_from_resume_df(resume_df: pd.DataFrame, resume_fields: KeywordDataFrameFields,
                           vectorizers: KeywordCountVectorizer, return_counts: bool = True, use_kw_names: bool = False):
    """
    Extract keywords from a resume dataframe. Returns the list of keywords found or a dict with each keyword count,
    as needed.

    Args:
        resume_df (pd.DataFrame): DataFrame containing a resume ID field, a language field and a resume field.
        resume_fields: class with column names from df.
        vectorizers (dict(KeywordCountVectorizer)): A dictionariy with two keys: 'fr' and 'en'. The values of those
        two keys are initialized KeywordCountVectorizer objects, with the corresponding language.
        return_counts (bool, optional): Set to true to return the keyword occurrence counts. Defaults to False.
        use_kw_names (bool, optional): Set to true to use the keyword names instead of the IDs.

    Returns:
        (list, dict): List of IDs of the keywords found or a dict with each keyword count, depending on return_counts.
    """
    assert df_has_correct_types(resume_df, RESUME_FIELDS), "Expected dataframe does not have correct types."
    keyword_count_dict = {}
    resume_field, language_field, resume_id_field = (
        resume_fields.resume_field,
        resume_fields.language_field,
        resume_fields.id_field,
    )
    for language, vectorizer in vectorizers.items():
        subset_resume_df = resume_df[resume_df[language_field] == language]
        docs = subset_resume_df[resume_field].to_list()

        subset_row2id = {row: resume_id for row, resume_id in enumerate(subset_resume_df[resume_id_field].tolist())}

        subset_count_dict = extract_keywords(
            docs,
            vectorizer,
            subset_row2id,
            return_counts=return_counts,
            use_kw_names=use_kw_names,
        )

        keyword_count_dict = keyword_count_dict | subset_count_dict

    return keyword_count_dict


def to_sparse_matrix(counts_dict: dict, keywords_df: pd.DataFrame, keywords_fields: KeywordDataFrameFields,
                     resumes_dict: bool = True, save_file: Union[None, str] = None):
    """
    Transforms a count dict to a sparse matrix.

    Input:
    counts_dict (dict): Count dict of format {resume_id: {keyword_id: count, ..}, ..} for a bank of resumes or
    {keyword_id: count, ..} for a job description. Use resumes_dict to distinguish both forms
    keywords_df: df that was used in the counts_dict
    keywords_fields: the class containing the columns in keywords_df
    resumes_dict: True or False depending on the counts_dict format
    save_file (Union[None, str], optional): Path to a file to save the sparse matrix to. Defaults to None.

    Output:
        tuple(csr_matrix, dict): Sparse matrix created, and mapping from dict keys (candidate IDs) to row number in the
        sparse matrix. If a job description dict was provided, the mapping is an empty dict.
    """
    assert df_has_correct_types(keywords_df, keywords_fields), "Expected dataframe does not have correct types."
    row2id = {}
    list_unique_ids = np.unique(keywords_df[keywords_fields.id_field]).tolist()
    col2id = {i: unique_id for i, unique_id in enumerate(list_unique_ids)}
    n_cols = len(list_unique_ids)
    if isinstance(counts_dict, dict) and len(counts_dict) == 0:  # if empty dict, return empty vector
        sparse_matrix = sparse.csr_matrix((1, n_cols))
        return sparse_matrix, row2id, col2id
    id2col = dict((y, x) for x, y in col2id.items())
    row_it = 0
    rows, cols, data = [], [], []
    if resumes_dict:
        for k in counts_dict:
            assert isinstance(counts_dict[k], dict) is True, \
                "Counts dict should be of format {resume_id: {keyword_id: count, ..}, ..}"
            for keyword_id, count in counts_dict[k].items():
                rows.append(row_it)
                cols.append(id2col[keyword_id])
                data.append(count)
            row2id[row_it] = k
            row_it += 1
    else:
        for k in counts_dict:
            assert isinstance(counts_dict[k], int) is True, \
                "Counts dict should be of format {keyword_id: count, ..}."
            rows.append(row_it)
            cols.append(id2col[k])
            data.append(counts_dict[k])
    rows = np.array(rows)
    cols = np.array(cols)
    shape = (max(row2id.keys()) + 1, n_cols) if row2id else (1, n_cols)
    sparse_matrix = sparse.csr_matrix((data, (rows, cols)), shape=shape)
    if save_file is not None:
        sparse.save_npz(save_file, sparse_matrix)
    return sparse_matrix, row2id, col2id


def ids2text(ids: Union[list, dict], keywords_df: pd.DataFrame, df_fields: KeywordDataFrameFields,
             language: str = ENGLISH):
    """
    Transforms keyword IDs to the keyword name.

    Args:
        ids (Union[list, dict]): List of keyword IDs or count dict with keyword IDs as keys.
        keywords_df (pd.DataFrame): DataFrame containing the keyword information (ID, name, translation in French)
        df_fields (KeywordDataFrameFields): Column names in the keywords_df Dataframe
        language (str, optional): Language of the keyword name. Defaults to 'en'.

    Returns:
        (dict or list): Same format as the input, with IDs changed to names.
    """
    assert df_has_correct_types(keywords_df, df_fields), "Expected dataframe does not have correct types."
    if isinstance(ids, dict):
        ids_array = np.array(list(ids.keys()))
        name_field = df_fields.fr_name_field if language == FRENCH else df_fields.eng_name_field
        try:
            text = [keywords_df[keywords_df[df_fields.id_field] == i][name_field].values[0] for i in ids_array]
        except IndexError:
            print("Check ids given in dictionary")
            return {}
        return {k: ids[i] for k, i in zip(text, ids_array)}
    else:
        name_field = df_fields.fr_name_field if language == FRENCH else df_fields.eng_name_field
        return [keywords_df[keywords_df[df_fields.id_field] == i][name_field].values[0] for i in ids]
    

def full_count_dict2text(count_dict: dict, keywords_df: pd.DataFrame, df_fields: KeywordDataFrameFields,
                         language: str = ENGLISH):
    """
    Transforms count dict's keyword IDs into strings. 

    Args:
        count_dict (dict): Dictionary for which the keys are document IDs (resume IDs), and the values are either a
        list of keyword IDs or count dictionaries with keyword IDs as keys
        keywords_df (pd.DataFrame): DataFrame containing the keyword information (ID, name, translation in French)
        df_fields (KeywordDataFrameFields): Column names in the keywords_df Dataframe
        language (str, optional): Language of the keyword name. Defaults to 'en'.

    Returns:
        dict: Same format as the input count_dict, with IDs changed to names.
    """
    assert df_has_correct_types(keywords_df, df_fields), "Expected dataframe does not have correct types."
    result = {}
    for key, value in count_dict.items():
        result[key] = ids2text(ids = value, keywords_df=keywords_df, df_fields=df_fields, language=language)
    return result


def compute_idf(count_matrix: sparse.csr_matrix):
    """
    Compute IDF from sparse matrix of keyword counts

    Args:
        count_matrix (csr_matrix): Sparse matrix of keyword counts

    Returns:
        csr_matrix: Sparse diagonal matrix of IDF of size (N, N) where N is the number of keywords.
    """
    n_samples, n_features = count_matrix.shape
    df = np.bincount(count_matrix.indices, minlength=n_features) + 1
    idf = np.log(n_samples / df) + 1
    idf_diag = sparse.diags(
        idf,
        offsets=0,
        shape=(n_features, n_features),
        format="csr",
        dtype=np.float64,
    )
    return idf_diag


def compute_tfidf(count_matrix: sparse.csr_matrix, idf_diag: sparse.csr_matrix):
    """
    Compute TF-IDF from a sparse matrix of counts and a sparse diagonal matrix of IDF

    Args:
        count_matrix (csr_matrix): Sparse matrix of keyword counts
        idf_diag (csr_matrix):  Sparse diagonal matrix of IDF

    Returns:
        csr_matrix: Sparse matrix of TF-IDF
    """
    words_per_doc = sparse.csr_matrix(1 / (count_matrix.sum(axis=1) + 1))
    tf = count_matrix.multiply(words_per_doc)
    tfidf = tf * idf_diag
    return tfidf


def create_skills_job_vectorizers(jobs_skills_df: pd.DataFrame, df_fields: classmethod):

    nlp_en = spacy.load("en_core_web_sm", disable=['tagger', 'parser', 'ner', 'lemmatizer'])
    nlp_fr = spacy.load("fr_core_news_sm", disable=['tagger', 'parser', 'ner', 'lemmatizer'])

    def tokenizer_fr(doc): return [x.orth_ for x in nlp_fr.tokenizer(doc)]
    def tokenizer_en(doc): return [x.orth_ for x in nlp_en.tokenizer(doc)]

    df_has_correct_types(jobs_skills_df, df_fields)
    job_skill_vectorizers = {}

    for lang, tokenizer in zip([ENGLISH, FRENCH], [tokenizer_en, tokenizer_fr]):
        job_skill_vectorizers[lang] = KeywordCountVectorizer(keywords_df=jobs_skills_df,
                                                             df_fields=df_fields, language=lang,
                                                             decode_error='ignore', tokenizer=tokenizer)
    return job_skill_vectorizers
